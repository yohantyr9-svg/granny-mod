package com.example.grannyescape;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class GrannyEscape implements ModInitializer {
	public static final String MOD_ID = "grannyescape";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	@Override
	public void onInitialize() {
		LOGGER.info("Granny Escape mod loaded!");

		// /grannyhello - proves the mod is installed and working
		CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
			dispatcher.register(Commands.literal("grannyhello").executes(context -> {
				context.getSource().sendSuccess(() -> Component.literal("Granny Escape mod is working!"), false);
				return 1;
			}));
		});
	}
}
